@echo off
REM Create deployment package for AWS Elastic Beanstalk

cd /d c:\Users\selma_3ct5ekw\Desktop\olap\olap-project\backend

echo.
echo ════════════════════════════════════════════════════════════════
echo            Creating Deployment Package for Beanstalk
echo ════════════════════════════════════════════════════════════════
echo.

REM Check if 7-Zip is installed, otherwise use Windows built-in
where 7z >nul 2>nul
if %ERRORLEVEL%==0 (
    echo Using 7-Zip...
    7z a -r -x!.venv -x!__pycache__ -x!*.pyc -x!.git -x!*.zip backend.zip ^
        main.py ^
        Procfile ^
        requirements.txt ^
        .ebextensions ^
        routers ^
        agents ^
        database ^
        models ^
        tools ^
        orchestrator ^
        diagnostics.py ^
        config.py ^
        utils.py
) else (
    echo Using Windows built-in compression...
    REM PowerShell compression
    powershell -Command "& {
        $files = @(
            'main.py',
            'Procfile',
            'requirements.txt',
            '.ebextensions',
            'routers',
            'agents',
            'database',
            'models',
            'tools',
            'orchestrator',
            'diagnostics.py',
            'config.py',
            'utils.py'
        );
        Compress-Archive -Path $files -DestinationPath 'backend.zip' -Force
    }"
)

echo.
echo ════════════════════════════════════════════════════════════════
echo ✅ Deployment package created: backend.zip
echo ════════════════════════════════════════════════════════════════
echo.
echo Next steps:
echo 1. Go to: https://console.aws.amazon.com/elasticbeanstalk/
echo 2. Select your environment: olap-analytics-env
echo 3. Click: "Upload and deploy"
echo 4. Select: backend.zip
echo 5. Click: "Upload and deploy"
echo.
echo Package location:
echo   %CD%\backend.zip
echo.
echo Package size:
dir backend.zip
echo.
pause
