@echo off
REM Redeploy to Elastic Beanstalk after configuration fix

cd /d c:\Users\selma_3ct5ekw\Desktop\olap\olap-project\backend

echo.
echo ════════════════════════════════════════════════════════════════
echo                Redeploying to Elastic Beanstalk
echo ════════════════════════════════════════════════════════════════
echo.

echo Step 1: Committing configuration changes...
git add .
git commit -m "Fix Beanstalk configuration: remove WSGIPath, use Uvicorn/ASGI"

echo.
echo Step 2: Redeploying...
eb deploy

echo.
echo ════════════════════════════════════════════════════════════════
echo                Deployment in Progress
echo ════════════════════════════════════════════════════════════════
echo.
echo Waiting for deployment to complete...
echo Check status with: eb status
echo View logs with: eb logs --stream
echo Open in browser with: eb open
echo.
pause
